# Pequenos Leitores 📚
Site de demonstração com catálogo, leitura de três PDFs de recontos originais de contos tradicionais de domínio público, leitores, empréstimos e devoluções.

## Publicação no Render
1. Envie **index.html** e a pasta **livros/** para a raiz do repositório GitHub.
2. No Render, crie um **Static Site** conectado ao repositório.
3. Use **Publish Directory**: `.` (ponto). Não precisa de comando de build.

## Limitações importantes
- A tela de entrada/cadastro é apenas **demonstração com apelido**, não login seguro. Não usa senha.
- Os dados de leitores e empréstimos ficam no `localStorage` de cada navegador, **não são compartilhados entre usuários**.
- Não cadastre dados pessoais reais, sobretudo de crianças. Para produção, implemente backend, autenticação e banco de dados com proteção de dados.
- Os PDFs são **recontos originais curtos** de contos tradicionais em domínio público, não edições integrais de livros históricos.
